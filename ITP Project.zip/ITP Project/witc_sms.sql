-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- දායකයා: 127.0.0.1
-- උත්පාදන වේලාව: ඔක්තෝම්බර් 13, 2020 දින 07:28 AM ට
-- සේවාදායකයේ අනුවාදය: 10.4.13-MariaDB
-- PHP අනුවාදය: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- දත්තගබඩාව: `witc_sms`
--

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `admin_users`
--

CREATE TABLE `admin_users` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `admin_users`
--

INSERT INTO `admin_users` (`ID`, `Name`, `UserName`, `Password`) VALUES
(1, 'Admin Muditha', 'admin', 'admin');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `course`
--

CREATE TABLE `course` (
  `ID` int(11) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Price` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `course`
--

INSERT INTO `course` (`ID`, `Title`, `Description`, `Price`) VALUES
(1, 'Diploma in ICT', '  Introduction to the study of one or more popular literary genres, such as mystery, crime fiction, urban romance, fantasy,  \r\n Introduction to the study of one or more popular literary genres, such as mystery, crime fiction, urban romance, fantasy,   \r\n', 15000),
(4, 'Diploma in Managment', 'askjdb jfwkab qwufbhiu iofwhqbi', 15000);

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `course_metirials`
--

CREATE TABLE `course_metirials` (
  `ID` int(11) NOT NULL,
  `CID` int(255) NOT NULL,
  `CMID` int(50) NOT NULL,
  `CourseMetirials` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `course_metirials`
--

INSERT INTO `course_metirials` (`ID`, `CID`, `CMID`, `CourseMetirials`, `Name`, `Description`) VALUES
(1, 1, 1, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 01', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(2, 1, 1, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 02', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(3, 1, 1, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 03', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(4, 1, 2, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 01', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(5, 1, 2, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 02', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(6, 1, 2, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 03', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(7, 1, 3, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 01', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(8, 1, 3, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 02', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(9, 1, 4, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 01', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(10, 1, 4, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 02', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(12, 1, 5, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 01', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(13, 1, 5, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 02', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(14, 1, 5, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 03', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(15, 1, 5, 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more', 'Lesson 04', 'At W3Schools you will find complete references about HTML elements, attributes, events, color names, entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more'),
(19, 4, 8, 'akjda iowdh iowhdeio iowqeh iowqhdeio ioqwhd  idoqwHN CAISUOBA', 'Lesson 01', 'akjda iowdh iowhdeio iowqeh iowqhdeio ioqwhd  idoqwHN CAISUOBA'),
(20, 4, 8, 'asdin ioDWNDOI   idowhio        DWION IOFso       325nkfasn iasfobioab ioafnsoib oifasn', 'Lesson 02', 'asdin ioDWNDOI   idowhio        DWION IOFso       325nkfasn iasfobioab ioafnsoib oifasn');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `course_student`
--

CREATE TABLE `course_student` (
  `ID` int(11) NOT NULL,
  `CID` int(50) NOT NULL,
  `ST_ID` int(11) NOT NULL,
  `ST_Name` varchar(255) NOT NULL,
  `ST_No` varchar(255) NOT NULL,
  `ST_Email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `course_student`
--

INSERT INTO `course_student` (`ID`, `CID`, `ST_ID`, `ST_Name`, `ST_No`, `ST_Email`) VALUES
(1, 1, 1, 'P. R. Muditha Mewan Senarathne', 'IT0001', 'mudithamewan12@gmail.com'),
(5, 4, 5, 'H.P.N.Hathurusinghe', 'BM0001', 'it19103082@my.sliit.lk');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `couse_module`
--

CREATE TABLE `couse_module` (
  `ID` int(11) NOT NULL,
  `CID` int(100) NOT NULL,
  `ModuleName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `couse_module`
--

INSERT INTO `couse_module` (`ID`, `CID`, `ModuleName`) VALUES
(1, 1, 'Introduction a PC'),
(2, 1, 'Microsoft Word'),
(3, 1, 'Microsoft Excel'),
(4, 1, 'Microsoft Power Point'),
(5, 1, 'Microsoft Access'),
(8, 4, 'Introduction to Management');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `exam_pool`
--

CREATE TABLE `exam_pool` (
  `ID` int(11) NOT NULL,
  `Question` varchar(255) NOT NULL,
  `An1` varchar(255) NOT NULL,
  `An2` varchar(255) NOT NULL,
  `An3` varchar(255) NOT NULL,
  `An4` varchar(255) NOT NULL,
  `CID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `exam_pool`
--

INSERT INTO `exam_pool` (`ID`, `Question`, `An1`, `An2`, `An3`, `An4`, `CID`) VALUES
(1, 'Who is the Bil Gates?', 'First Programmer in the World', 'CEO of Microsoft', 'CEO of Facebook', 'CEO of IDM', 1),
(2, 'Chooes the Microsoft Application.', 'Photoshop', 'AfterEfect', 'HTML', 'Visual Studio', 1),
(3, 'What is PC?', 'Personal Computer', 'PHP Creation', 'Processing Center', 'No Answer', 1),
(4, 'Chooes a web browser.', 'Word', 'Power Point', 'Excel', 'Chrome', 1),
(5, 'Chooes a Serch Engin.', 'Google', 'ASK', 'Being', 'All Above', 1),
(12, 'what is awasitita periwaya?', 'redwap', 'kigsottenns', 'xmaster', 'pronhub', 4);

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `lecturer`
--

CREATE TABLE `lecturer` (
  `id` int(11) NOT NULL,
  `Date_Time` varchar(255) NOT NULL DEFAULT current_timestamp(),
  `Name` varchar(255) NOT NULL,
  `IN_ID` varchar(50) NOT NULL,
  `Course` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Contact_Number` int(13) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `lecturer`
--

INSERT INTO `lecturer` (`id`, `Date_Time`, `Name`, `IN_ID`, `Course`, `Email`, `Contact_Number`, `Address`, `UserName`, `Password`) VALUES
(1, '2020-10-12 09:59:30', 'Mr. Mewan Senarathne', 'LIT0001', '1', 'muditha.witc@gmail.com', 781528147, 'Hapuvita,Udagama\r\nMoronthota', 'muditha.witc@gmail.com', 'muditha'),
(3, '2020-10-12 22:01:50', 'Pasindu Nayanajith', '0001', '4', 'pasindunayanjith98@gmail.com', 713519574, '78/34 parakum mawatha ,lake round ,kurunegala', 'pasindu123', 'pasindu123');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `payment`
--

CREATE TABLE `payment` (
  `ID` int(11) NOT NULL,
  `SID` int(50) NOT NULL,
  `ST_ID` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Month` varchar(50) NOT NULL,
  `Year` varchar(100) NOT NULL,
  `Ammount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `payment`
--

INSERT INTO `payment` (`ID`, `SID`, `ST_ID`, `Name`, `Month`, `Year`, `Ammount`) VALUES
(1, 1, 'IT0001', 'P. R. Muditha Mewan Senarathne', 'January', '2020', 2500),
(2, 1, 'IT0001', 'P. R. Muditha Mewan Senarathne', 'February', '2020', 2500),
(3, 1, 'IT0001', 'P. R. Muditha Mewan Senarathne', 'March', '2020', 2500),
(5, 1, 'IT0001', 'P. R. Muditha Mewan Senarathne', 'January', '2020', 1200),
(6, 5, 'BM0001', 'H.P.N.Hathurusinghe', 'January', '2020', 2500);

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `quiz_name`
--

CREATE TABLE `quiz_name` (
  `id` int(11) NOT NULL,
  `CID` int(100) NOT NULL,
  `Quiz_Name` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `quiz_name`
--

INSERT INTO `quiz_name` (`id`, `CID`, `Quiz_Name`, `Description`) VALUES
(2, 1, 'Quiz 01', 'Fill All');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `quiz_question`
--

CREATE TABLE `quiz_question` (
  `id` int(11) NOT NULL,
  `CID` int(100) NOT NULL,
  `QNID` int(100) NOT NULL,
  `Quection` varchar(255) NOT NULL,
  `an1` varchar(255) NOT NULL,
  `an2` varchar(255) NOT NULL,
  `an3` varchar(255) NOT NULL,
  `an4` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `quiz_question`
--

INSERT INTO `quiz_question` (`id`, `CID`, `QNID`, `Quection`, `an1`, `an2`, `an3`, `an4`) VALUES
(5, 1, 2, 'Chooes the Microsoft Application.', 'Photoshop', 'AfterEfect', 'HTML', 'Visual Studio'),
(6, 1, 2, 'Who is the Bil Gates?', 'First Programmer in the World', 'CEO of Microsoft', 'CEO of Facebook', 'CEO of IDM'),
(7, 1, 2, 'Chooes a Serch Engin.', 'Google', 'ASK', 'Being', 'All Above'),
(9, 1, 2, 'What is PC?', 'Personal Computer', 'PHP Creation', 'Processing Center', 'No Answer'),
(10, 1, 2, 'Chooes a web browser.', 'Word', 'Power Point', 'Excel', 'Chrome');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `quiz_submited`
--

CREATE TABLE `quiz_submited` (
  `ID` int(11) NOT NULL,
  `ST_ID` int(100) NOT NULL,
  `Quiz_ID` int(100) NOT NULL,
  `Que1` varchar(255) NOT NULL,
  `an1` varchar(255) NOT NULL,
  `Que2` varchar(255) NOT NULL,
  `an2` varchar(255) NOT NULL,
  `Que3` varchar(255) NOT NULL,
  `an3` varchar(255) NOT NULL,
  `Que4` varchar(255) NOT NULL,
  `an4` varchar(255) NOT NULL,
  `Que5` varchar(255) NOT NULL,
  `an5` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `student`
--

CREATE TABLE `student` (
  `ID` int(11) NOT NULL,
  `Date_Time` varchar(255) NOT NULL DEFAULT current_timestamp(),
  `Name` varchar(255) NOT NULL,
  `ST_ID` varchar(50) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Contact_Number` int(13) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `student`
--

INSERT INTO `student` (`ID`, `Date_Time`, `Name`, `ST_ID`, `Email`, `Contact_Number`, `Address`, `UserName`, `Password`) VALUES
(1, '2020-10-11 20:29:47', 'P. R. Muditha Mewan Senarathne', 'IT0001', 'mudithamewan12@gmail.com', 781528147, 'Kegalle', 'mudithamewan12@gmail.com', '992800925v'),
(5, '2020-10-12 21:58:39', 'H.P.N.Hathurusinghe', 'BM0001', 'it19103082@my.sliit.lk', 782462424, '23/A parakum mawatha , lake round,kurunegala\r\n', 'BM0001', 'student123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `course_metirials`
--
ALTER TABLE `course_metirials`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `course_student`
--
ALTER TABLE `course_student`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `couse_module`
--
ALTER TABLE `couse_module`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `exam_pool`
--
ALTER TABLE `exam_pool`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `quiz_name`
--
ALTER TABLE `quiz_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_question`
--
ALTER TABLE `quiz_question`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quiz_submited`
--
ALTER TABLE `quiz_submited`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `course_metirials`
--
ALTER TABLE `course_metirials`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `course_student`
--
ALTER TABLE `course_student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `couse_module`
--
ALTER TABLE `couse_module`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `exam_pool`
--
ALTER TABLE `exam_pool`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lecturer`
--
ALTER TABLE `lecturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quiz_name`
--
ALTER TABLE `quiz_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz_question`
--
ALTER TABLE `quiz_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `quiz_submited`
--
ALTER TABLE `quiz_submited`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
